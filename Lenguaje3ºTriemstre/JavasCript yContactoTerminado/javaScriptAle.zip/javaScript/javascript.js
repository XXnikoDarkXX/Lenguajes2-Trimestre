


/*Declaramos e inicializamos las variables q contiene los parrafos a mostrar segun
la elecion q se haga en la funcion q les sigue*/
	var parrafoP0 = "Pez de agua dulce.";
	var parrafoP1="El pez betta (Betta Splendens) es también conocido como pez luchador de Siam." + 
	",  son también populares en Tailandia, Vietnam, Camboya y Laos.";  
	var parrafoP2="El guppy (Poecilia reticulata) también conocido como lebistes o pez millón,"; 
	var parrafoP3="El pez Ángel o pez Escalar, Pterophyllun scalare, es un pez de la familia de los cíclidos de agua dulce y caliente."; 
	var parrafoP4="Como son peces agresivos no pueden vivir en conjunto con otros de su misma especie ya que tienden a pelear.";
	var parrafoP5="Son bastante pacíficos, aunque hay que tener cuidado con sus acompañantes, ya que tienden a morder sus grandes y coloridas colas.";
	var parrafoP6="Son muy apreciados, porque poseen un comportamiento muy pacífico. ";
	var reset =" ";

/*Script para el select */
	function miFuncion (){		
/*En la variable opcion almacenaremos la id del select, cuando se eliga una opcion 
esta varible se igualara a los value de la opcion selecionada*/		
		var opcion = document.getElementById("opcionElegida").value;
//mediante un if podemos hacer que muestre los diferentes parrafos segun eleccion
if (opcion == "Betta blanco") {
	document.getElementById("parrafo").innerHTML = parrafoP1;
	document.getElementById("parrafo0").innerHTML = parrafoP0;
	document.getElementById("parrafo1").innerHTML = parrafoP4;
}
if (opcion == "Guppy multicolor") {
	document.getElementById("parrafo0").innerHTML = parrafoP0;
	document.getElementById("parrafo").innerHTML = reset;
	document.getElementById("parrafo").innerHTML = parrafoP2;
	document.getElementById("parrafo1").innerHTML = reset;
	document.getElementById("parrafo1").innerHTML = parrafoP5;


}
if (opcion == "Escalar blanco") {
	document.getElementById("parrafo0").innerHTML = parrafoP0;
	document.getElementById("parrafo").innerHTML = reset;
	document.getElementById("parrafo").innerHTML = parrafoP3;
	document.getElementById("parrafo1").innerHTML = reset;
	document.getElementById("parrafo1").innerHTML = parrafoP6;
}		
	/*Salida de ventana por pantalla*/
	alert("Has selecionado " + opcion);			
}



/*Script de imagen oculta*/

function mostrar(id){

	var objeto = document.getElementById(id)

        objeto.style.display = "block";

}


function ocultar(id){

    var objeto = document.getElementById(id)

        objeto.style.display = "none";

}